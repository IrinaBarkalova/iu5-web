import {OsComponent} from "./OsComponent.js";
import {BackButtonComponent} from "../components/back-button/BackButtonComponent.js";
import {MainPage} from "../pages/main/MainPage.js";
import {ajax} from "../modules/ajax.js";
import {urls} from "../modules/urls.js";

export class OsPage {
    data1;
    constructor(parent, id) {
        this.parent = parent
        this.id = id
    }
    clickBack() {
        const mainPage = new MainPage(this.parent)
        mainPage.render()
    }
    async getData() {
        return ajax.get(urls.os(this.id))
    }

    async render() {
        this.parent.innerHTML = ''
        const html = this.getHTML()
        this.parent.insertAdjacentHTML('beforeend', html)
        const backButton = new BackButtonComponent(this.page)
        backButton.render(this.clickBack.bind(this))
        const data = await this.getData()
        const osComp = new OsComponent(this.page)
        osComp.render(data.data)
    }

    get page() {
        return document.getElementById('stock-page')
    }

    getHTML() {
        return (
            `
                <div id="stock-page">
                </div>
            `
        )
    }


}
